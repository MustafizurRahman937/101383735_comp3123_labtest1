const fs = require('fs');
const path = require('path');

const directory = './Logs';

if (!fs.existsSync(directory)) {
  fs.mkdirSync(directory);
}

process.chdir(directory);

for (let i = 1; i <= 10; i++) {
  var logFileName = `log${i}.txt`;
  var logFileContent = `Content for log file${i}.`;

  fs.writeFileSync(logFileName, logFileContent);

  console.log(logFileName);
}


